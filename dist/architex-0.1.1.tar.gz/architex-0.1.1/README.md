A package to auto draw your software architecture diagram from your source code.

Current limitation :
Your source code should be consist of docker compose (required) and nginx (optional) configuration file.
